
  # Interfaz de creación musical

  This is a code bundle for Interfaz de creación musical. The original project is available at https://www.figma.com/design/twJGvaytLYzwAu2Jech3Hu/Interfaz-de-creaci%C3%B3n-musical.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  