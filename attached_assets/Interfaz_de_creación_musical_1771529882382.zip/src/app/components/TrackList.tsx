import React from 'react';
import { Play, Pause, Download, Share2, MoreVertical } from 'lucide-react';
import { motion } from 'motion/react';

interface Track {
  id: string;
  title: string;
  description: string;
  genre: string;
  duration: string;
  imageUrl: string;
  isPlaying: boolean;
}

interface TrackListProps {
  tracks: Track[];
  onPlay: (id: string) => void;
  onPause: () => void;
}

export function TrackList({ tracks, onPlay, onPause }: TrackListProps) {
  return (
    <div className="relative">
      {/* Glow effect */}
      <div className="absolute -inset-1 bg-gradient-to-r from-indigo-600 to-orange-600 rounded-2xl blur-xl opacity-20"></div>
      
      <div className="relative bg-gradient-to-br from-slate-900/90 to-indigo-900/30 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-white">Tus Creaciones</h2>
          <span className="text-sm text-orange-300/60">{tracks.length} pistas</span>
        </div>

        <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
          {tracks.length === 0 ? (
            <div className="text-center py-12 text-orange-300/60">
              <p>No hay pistas todavía. ¡Crea tu primera!</p>
            </div>
          ) : (
            tracks.map((track, index) => (
              <motion.div
                key={track.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`group relative rounded-xl overflow-hidden transition-all ${
                  track.isPlaying
                    ? 'bg-gradient-to-r from-orange-600/30 to-indigo-600/30 border border-orange-500/50'
                    : 'bg-black/30 border border-white/10 hover:border-orange-500/30'
                }`}
              >
                <div className="flex items-center gap-4 p-4">
                  {/* Album Art */}
                  <div className="relative flex-shrink-0">
                    <img
                      src={track.imageUrl}
                      alt={track.title}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => track.isPlaying ? onPause() : onPlay(track.id)}
                      className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg"
                    >
                      {track.isPlaying ? (
                        <Pause className="w-6 h-6 text-white" fill="white" />
                      ) : (
                        <Play className="w-6 h-6 text-white" fill="white" />
                      )}
                    </motion.button>
                  </div>

                  {/* Track Info */}
                  <div className="flex-1 min-w-0">
                    <h3 className="text-white font-medium truncate">{track.title}</h3>
                    <p className="text-sm text-orange-300/60 truncate">{track.description}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-xs px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-300 border border-orange-500/30">
                        {track.genre}
                      </span>
                      <span className="text-xs text-orange-300/60">{track.duration}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-2 rounded-lg hover:bg-white/10 transition-colors">
                      <Download className="w-4 h-4 text-orange-300" />
                    </button>
                    <button className="p-2 rounded-lg hover:bg-white/10 transition-colors">
                      <Share2 className="w-4 h-4 text-orange-300" />
                    </button>
                    <button className="p-2 rounded-lg hover:bg-white/10 transition-colors">
                      <MoreVertical className="w-4 h-4 text-orange-300" />
                    </button>
                  </div>
                </div>

                {/* Playing indicator */}
                {track.isPlaying && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-orange-500 to-indigo-500">
                    <motion.div
                      className="h-full bg-white/50"
                      initial={{ width: '0%' }}
                      animate={{ width: '100%' }}
                      transition={{ duration: 3, repeat: Infinity }}
                    />
                  </div>
                )}
              </motion.div>
            ))
          )}
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.2);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(249, 115, 22, 0.4);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(249, 115, 22, 0.6);
        }
      `}</style>
    </div>
  );
}