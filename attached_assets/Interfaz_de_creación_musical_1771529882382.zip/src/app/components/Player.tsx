import React, { useState, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, X, Repeat, Shuffle } from 'lucide-react';
import { Slider } from './ui/slider';
import { motion, AnimatePresence } from 'motion/react';

interface Track {
  id: string;
  title: string;
  description: string;
  genre: string;
  duration: string;
  imageUrl: string;
  isPlaying: boolean;
}

interface PlayerProps {
  track: Track;
  onClose: () => void;
}

export function Player({ track, onClose }: PlayerProps) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(['0']);
  const [volume, setVolume] = useState(['70']);
  const [isMuted, setIsMuted] = useState(false);
  const [isRepeat, setIsRepeat] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);

  // Parse duration
  const [durationMins, durationSecs] = track.duration.split(':').map(Number);
  const totalSeconds = durationMins * 60 + durationSecs;

  // Simulate playback
  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setCurrentTime((prev) => {
          const current = parseInt(prev[0]);
          if (current >= totalSeconds) {
            setIsPlaying(false);
            return ['0'];
          }
          return [(current + 1).toString()];
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isPlaying, totalSeconds]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        className="fixed bottom-0 left-0 right-0 z-50"
      >
        {/* Backdrop blur */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/95 to-transparent backdrop-blur-xl"></div>
        
        <div className="relative border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            {/* Close button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full hover:bg-white/10 transition-colors"
            >
              <X className="w-4 h-4 text-orange-300" />
            </button>

            <div className="grid grid-cols-3 gap-4 items-center">
              {/* Left - Track Info */}
              <div className="flex items-center gap-3">
                <motion.img
                  src={track.imageUrl}
                  alt={track.title}
                  className="w-14 h-14 rounded-lg object-cover"
                  animate={{ scale: isPlaying ? [1, 1.05, 1] : 1 }}
                  transition={{ duration: 2, repeat: isPlaying ? Infinity : 0 }}
                />
                <div className="min-w-0">
                  <h4 className="text-white font-medium truncate">{track.title}</h4>
                  <p className="text-sm text-orange-300/60 truncate">{track.genre}</p>
                </div>
              </div>

              {/* Center - Controls */}
              <div className="flex flex-col items-center gap-2">
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setIsShuffle(!isShuffle)}
                    className={`p-2 rounded-lg transition-colors ${
                      isShuffle ? 'text-orange-400' : 'text-orange-300/60 hover:text-orange-300'
                    }`}
                  >
                    <Shuffle className="w-4 h-4" />
                  </button>
                  
                  <button className="p-2 rounded-lg hover:bg-white/10 transition-colors">
                    <SkipBack className="w-5 h-5 text-orange-300" fill="currentColor" />
                  </button>
                  
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="p-3 rounded-full bg-gradient-to-r from-orange-600 to-orange-500 hover:shadow-lg hover:shadow-orange-500/50 transition-all"
                  >
                    {isPlaying ? (
                      <Pause className="w-5 h-5 text-white" fill="white" />
                    ) : (
                      <Play className="w-5 h-5 text-white" fill="white" />
                    )}
                  </motion.button>
                  
                  <button className="p-2 rounded-lg hover:bg-white/10 transition-colors">
                    <SkipForward className="w-5 h-5 text-orange-300" fill="currentColor" />
                  </button>
                  
                  <button
                    onClick={() => setIsRepeat(!isRepeat)}
                    className={`p-2 rounded-lg transition-colors ${
                      isRepeat ? 'text-orange-400' : 'text-orange-300/60 hover:text-orange-300'
                    }`}
                  >
                    <Repeat className="w-4 h-4" />
                  </button>
                </div>

                {/* Progress Bar */}
                <div className="w-full flex items-center gap-3">
                  <span className="text-xs text-orange-300/60 min-w-[40px]">
                    {formatTime(parseInt(currentTime[0]))}
                  </span>
                  <Slider
                    value={currentTime}
                    onValueChange={(value) => setCurrentTime(value.map(String))}
                    max={totalSeconds}
                    step={1}
                    className="flex-1"
                  />
                  <span className="text-xs text-orange-300/60 min-w-[40px]">
                    {track.duration}
                  </span>
                </div>
              </div>

              {/* Right - Volume */}
              <div className="flex items-center justify-end gap-3">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-2 rounded-lg hover:bg-white/10 transition-colors"
                >
                  {isMuted || volume[0] === '0' ? (
                    <VolumeX className="w-5 h-5 text-orange-300" />
                  ) : (
                    <Volume2 className="w-5 h-5 text-orange-300" />
                  )}
                </button>
                <Slider
                  value={isMuted ? ['0'] : volume}
                  onValueChange={(value) => {
                    setVolume(value.map(String));
                    setIsMuted(false);
                  }}
                  max={100}
                  step={1}
                  className="w-24"
                />
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}