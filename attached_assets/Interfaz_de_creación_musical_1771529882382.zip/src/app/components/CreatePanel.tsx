import React, { useState } from 'react';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Slider } from './ui/slider';
import { Wand2, Music, Clock, Palette } from 'lucide-react';
import { motion } from 'motion/react';

interface CreatePanelProps {
  onGenerate: (prompt: string, genre: string, mood: string, duration: string) => void;
  isGenerating: boolean;
}

export function CreatePanel({ onGenerate, isGenerating }: CreatePanelProps) {
  const [prompt, setPrompt] = useState('');
  const [genre, setGenre] = useState('pop');
  const [mood, setMood] = useState('upbeat');
  const [duration, setDuration] = useState(['180']);

  const handleGenerate = () => {
    if (prompt.trim()) {
      const mins = Math.floor(parseInt(duration[0]) / 60);
      const secs = parseInt(duration[0]) % 60;
      onGenerate(prompt, genre, mood, `${mins}:${secs.toString().padStart(2, '0')}`);
    }
  };

  return (
    <div className="relative">
      {/* Glow effect */}
      <div className="absolute -inset-1 bg-gradient-to-r from-orange-600 to-indigo-600 rounded-2xl blur-xl opacity-20"></div>
      
      <div className="relative bg-gradient-to-br from-slate-900/90 to-indigo-900/30 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
        <div className="flex items-center gap-2 mb-6">
          <Wand2 className="w-5 h-5 text-orange-400" />
          <h2 className="text-xl font-semibold text-white">Crea tu Sonido</h2>
        </div>

        <div className="space-y-6">
          {/* Prompt */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-orange-300 flex items-center gap-2">
              <Music className="w-4 h-4" />
              Describe tu música
            </label>
            <div className="relative">
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Una pista de synthwave soñadora con vibras nostálgicas de los 80s, con pads exuberantes y arpegios energéticos..."
                className="min-h-[120px] bg-black/40 border-orange-500/30 text-white placeholder:text-orange-300/40 focus:border-orange-500/60 focus:ring-orange-500/20 rounded-xl resize-none"
              />
              <div className="absolute bottom-3 right-3 text-xs text-orange-300/40">
                {prompt.length}/500
              </div>
            </div>
          </div>

          {/* Genre */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-orange-300 flex items-center gap-2">
              <Palette className="w-4 h-4" />
              Género
            </label>
            <Select value={genre} onValueChange={setGenre}>
              <SelectTrigger className="bg-black/40 border-orange-500/30 text-white focus:border-orange-500/60 focus:ring-orange-500/20 rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-orange-500/30">
                <SelectItem value="pop">Pop</SelectItem>
                <SelectItem value="rock">Rock</SelectItem>
                <SelectItem value="electronic">Electrónica</SelectItem>
                <SelectItem value="hiphop">Hip Hop</SelectItem>
                <SelectItem value="jazz">Jazz</SelectItem>
                <SelectItem value="classical">Clásica</SelectItem>
                <SelectItem value="ambient">Ambient</SelectItem>
                <SelectItem value="synthwave">Synthwave</SelectItem>
                <SelectItem value="lofi">Lo-Fi</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Mood */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-orange-300">Estado de Ánimo</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { key: 'upbeat', label: 'Animado' },
                { key: 'chill', label: 'Relajado' },
                { key: 'dark', label: 'Oscuro' },
                { key: 'energetic', label: 'Energético' },
                { key: 'melancholic', label: 'Melancólico' },
                { key: 'dreamy', label: 'Soñador' }
              ].map((m) => (
                <button
                  key={m.key}
                  onClick={() => setMood(m.key)}
                  className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    mood === m.key
                      ? 'bg-gradient-to-r from-orange-600 to-orange-500 text-white shadow-lg shadow-orange-500/30'
                      : 'bg-black/40 text-orange-300 border border-orange-500/30 hover:border-orange-500/60'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Duration */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-orange-300 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Duración
              </span>
              <span className="text-orange-400">
                {Math.floor(parseInt(duration[0]) / 60)}:{(parseInt(duration[0]) % 60).toString().padStart(2, '0')}
              </span>
            </label>
            <Slider
              value={duration}
              onValueChange={(value) => setDuration(value.map(String))}
              min={30}
              max={300}
              step={10}
              className="py-4"
            />
            <div className="flex justify-between text-xs text-orange-300/60">
              <span>0:30</span>
              <span>5:00</span>
            </div>
          </div>

          {/* Generate Button */}
          <motion.button
            onClick={handleGenerate}
            disabled={!prompt.trim() || isGenerating}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 text-white font-semibold disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-2xl hover:shadow-orange-500/50 transition-all relative overflow-hidden group"
          >
            {isGenerating ? (
              <span className="flex items-center justify-center gap-2">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                >
                  <Wand2 className="w-5 h-5" />
                </motion.div>
                Generando tu obra maestra...
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">
                <Wand2 className="w-5 h-5" />
                Generar Música
              </span>
            )}
            <div className="absolute inset-0 bg-gradient-to-r from-orange-500 to-orange-600 opacity-0 group-hover:opacity-100 transition-opacity -z-10"></div>
          </motion.button>
        </div>
      </div>
    </div>
  );
}